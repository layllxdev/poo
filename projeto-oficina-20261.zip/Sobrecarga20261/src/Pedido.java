import java.util.*;

public class Pedido {
    private Cliente cliente;
    private List<ItemProduto> itens;

    static void main() {
        Produto p1 = new Produto("Filtro de óleo", 45.99);

        ItemProduto ip1 = new ItemProduto(p1, 3);
        p1.setPreco(52.49);
        ItemProduto ip2 = new ItemProduto(p1, 2);
    }
}
