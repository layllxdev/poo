package oficina;

public class AgendamentoUrgente extends Agendamento {
    private double taxaUrgencia;

    public AgendamentoUrgente(Cliente cliente, Veiculo veiculo, double taxaUrgencia) {
        super(cliente, veiculo);
        this.taxaUrgencia = taxaUrgencia;
    }

    @Override
    public double getCustoTotal() {
        return super.getCustoTotal() + taxaUrgencia;
    }
}
