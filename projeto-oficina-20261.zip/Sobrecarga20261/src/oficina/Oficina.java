package oficina;

import java.util.*;

public class Oficina {
    private List<Agendamento> agendamentos = new ArrayList<>();

    public void adicionar(Agendamento a) {
        agendamentos.add(a);
    }

    public List<Agendamento> getAgendamentos() {
        return Collections.unmodifiableList(agendamentos);
    }

    public void gerarRelatorio() {
        for (Agendamento a : getAgendamentos()) {
            System.out.printf("""
                    Cliente: %s
                    Tipo: %s
                    Custo: R$%.2f 
                    """, a.getCliente().getNome(),
                    a.getClass().getSimpleName(),
                    a.getCustoTotal());
        }
    }
}
