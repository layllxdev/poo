package oficina;

public class AgendamentoRetorno extends Agendamento {

    private double desconto = 15;

    public AgendamentoRetorno(Cliente cliente, Veiculo veiculo) {
        super(cliente, veiculo);
    }

    public AgendamentoRetorno(Cliente cliente, Veiculo veiculo, double desconto) {
        super(cliente, veiculo);
        this.desconto = desconto;
    }

    @Override
    public double getCustoTotal() {
        return super.getCustoTotal() * ( 1 - desconto / 100);
    }
}
